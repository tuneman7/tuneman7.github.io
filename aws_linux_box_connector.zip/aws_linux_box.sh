chmod 400 rsa_key_for_instance.pem
chmod 777 ./remote_run.sh
chmod 777 ./rp.sh
scp -oStrictHostKeyChecking=no -oUserKnownHostsFile=/dev/null -i "rsa_key_for_instance.pem" ./remote_run.sh ubuntu@35.91.235.115:run.sh
scp -oStrictHostKeyChecking=no -oUserKnownHostsFile=/dev/null -i "rsa_key_for_instance.pem" ./rp.sh ubuntu@35.91.235.115:rp.sh
ssh -oStrictHostKeyChecking=no -oUserKnownHostsFile=/dev/null -i "rsa_key_for_instance.pem" ubuntu@35.91.235.115
