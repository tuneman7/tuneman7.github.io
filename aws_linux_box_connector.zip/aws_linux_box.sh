chmod 400 rsa_key_for_instance.pem
chmod 777 ./remote_run.sh
chmod 777 ./rp.sh
scp -oStrictHostKeyChecking=no -oUserKnownHostsFile=/dev/null -i "rsa_key_for_instance.pem" ./remote_run.sh ubuntu@34.222.172.233:run.sh
scp -oStrictHostKeyChecking=no -oUserKnownHostsFile=/dev/null -i "rsa_key_for_instance.pem" ./rp.sh ubuntu@34.222.172.233:rp.sh
ssh -oStrictHostKeyChecking=no -oUserKnownHostsFile=/dev/null -i "rsa_key_for_instance.pem" ubuntu@34.222.172.233
