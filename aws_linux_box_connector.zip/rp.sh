#!/bin/bash
sleep 2
docker ps
 cd ./zukangy_don_collaboration/ && . ./run205final.sh
