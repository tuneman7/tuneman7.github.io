chmod 400 rsa_key_for_instance.pem
chmod 777 ./remote_run.sh
chmod 777 ./rp.sh
scp -oStrictHostKeyChecking=no -oUserKnownHostsFile=/dev/null -i "rsa_key_for_instance.pem" ./remote_run.sh ubuntu@35.93.18.148:run.sh
scp -oStrictHostKeyChecking=no -oUserKnownHostsFile=/dev/null -i "rsa_key_for_instance.pem" ./wait_for_jn.sh ubuntu@35.93.18.148:wait_for_jn.sh
scp -oStrictHostKeyChecking=no -oUserKnownHostsFile=/dev/null -i "rsa_key_for_instance.pem" ./rp.sh ubuntu@35.93.18.148:rp.sh
scp -oStrictHostKeyChecking=no -oUserKnownHostsFile=/dev/null -i "rsa_key_for_instance.pem" ./view_log.sh ubuntu@35.93.18.148:view_log.sh
ssh -oStrictHostKeyChecking=no -oUserKnownHostsFile=/dev/null -i "rsa_key_for_instance.pem" ubuntu@35.93.18.148
