#!/bin/bash
finished=false

echo "*********************************"
echo "*                               *"
echo "* Waiting for setup on box to   *"
echo "*         Complete              *"
echo "*                               *"
echo "*********************************"


while ! $finished; do
    docker ps &>/dev/null
    if [ $? -eq 0 ]; then
        finished=true
        echo "*********************************"
        echo "*                               *"
        echo "* Setup on the box is complete  *"
        echo "*    Run the command below      *"
        echo "*                               *"
        echo "*********************************"
        echo ""
        echo "*********************************"

        echo " sudo su"        
        echo ". rp.sh"
        echo "*********************************"
    else

        finished=false
    fi
done
#. rp.sh
echo""
echo""

