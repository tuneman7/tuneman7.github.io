#!/bin/bash

cd ./w255_deployers/lab3_k8
tail -f log.txt
