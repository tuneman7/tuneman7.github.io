#!/bin/bash
sleep 2
docker ps
cd ./w255_deployers/lab3_k8

. run.sh

return

while ${prompt_for_exit}; do
        echo "*********************************"
        echo "*                               *"
        echo "*    Run the Deployer           *"
        echo "*                               *"        
        echo "*********************************"
        while true; do
            read -p "Do wish to kill exit? [y/n]:" yn
            case $yn in
                [Yy]* ) do_exit=1;break;;
                [Nn]* ) do_exit=0;break;;
                * ) echo "Please answer \"y\" or \"n\".";;
            esac
        done        
break
 
done


if [[ "$do_exit" -eq 1 ]]
then
echo "*********************************"
echo "*                               *"
echo "*        exiting                *"
echo "*                               *"
echo "*********************************"
return
fi


. run.sh
