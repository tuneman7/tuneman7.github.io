#!/bin/bash

echo "*********************************"
echo "*                               *"
echo "* Waiting for the application   *"
echo "*        to come up             *"
echo "*                               *"
echo "*********************************"

finished=false
while ! $finished; do
    health_status=$(curl -o /dev/null -s -w "%{http_code}\n" -X GET "http://52.32.179.167:8000/health")
    if [ $health_status == "200" ]; then
        finished=true
        echo "***********************************"
        echo "*                                 *"
        echo "* Health Check URL                *"
        echo "* http://52.32.179.167:8000/docs *"
        echo "*                                 *"
        echo "***********************************"
    else
        finished=false
    fi
done
echo""
echo""


echo "***********************************"
echo "*                                 *"
echo "* Grafana dashboard               *"
echo "* http://52.32.179.167:3000 *"
echo "*                                 *"
echo "***********************************"


echo "*********************************"
echo "*                               *"
echo "* Waiting for health check      *"
echo "*        to come up             *"
echo "*                               *"
echo "*********************************"


echo "***********************************"
echo "*                                 *"
echo "* API Health Check -- Good!       *"
echo "* http://52.32.179.167:8000/docs  *"
echo "*                                 *"
echo "***********************************"



