chmod 400 rsa_key_for_instance.pem
chmod 777 ./remote_run.sh
chmod 777 ./rp.sh
ssh -oStrictHostKeyChecking=no -oUserKnownHostsFile=/dev/null -i "rsa_key_for_instance.pem" ubuntu@34.209.240.22
