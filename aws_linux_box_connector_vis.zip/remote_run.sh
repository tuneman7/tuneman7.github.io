#!/bin/bash
finished=false

echo "*********************************"
echo "*                               *"
echo "* Waiting for setup on box to   *"
echo "*         Complete              *"
echo "*                               *"
echo "*********************************"


while ! $finished; do
    python --version &>/dev/null
    if [ $? -eq 0 ]; then
        finished=true
        echo "*********************************"
        echo "*                               *"
        echo "* Setup on the box is complete  *"
        echo "*                               *"
        echo "*********************************"
    else

        finished=false
    fi
done
#. rp.sh
echo""
echo""

